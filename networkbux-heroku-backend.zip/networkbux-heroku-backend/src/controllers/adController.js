import { Ads } from "../models/ads";
import { AdClick } from "../models/adClick";
const create_ad = async (req, res) => {
  const user = req.user._id;
  try {
    let ads = await Ads.findOne({ link: req.body.link });
    if (ads) return res.status(400).send("Ads already Save.");
    ads = new Ads(req.body);
    ads.user = user;
    await ads.save();
  } catch (err) {
    return res.json({ error: err.message });
  }

  return res.json({
    message: "Ads is Created",
  });
};

const ad_list = async (req, res) => {
  const user_id = req.user._id;
  try {
    // const currentPage = parseInt(req.query.page) || 1;
    // const eachPage = 10; // You can adjust this based on your preference.

    // const totalAds = await Ads.countDocuments({ user: user_id });
    // const totalPages = Math.ceil(totalAds / eachPage);

    const adlist = await Ads.find({ user: user_id });
    // .skip((currentPage - 1) * eachPage)
    // .limit(eachPage);

    const response = {
      data: adlist,
      // meta: {
      //   total: totalAds,
      //   currentPage,
      //   eachPage,
      //   lastPage: totalPages,
      // },
      status: 200,
    };

    return res.json(response);
  } catch (err) {
    return res.json({ error: err.message });
  }
};

const ads_public = async (req, res) => {
  try {
    const currentPage = parseInt(req.query.page) || 1;
    const eachPage = 10; // You can adjust this based on your preference.

    const totalAds = await Ads.countDocuments();
    const totalPages = Math.ceil(totalAds / eachPage);

    const adslist = await Ads.find()
      .skip((currentPage - 1) * eachPage)
      .limit(eachPage);

    const response = {
      data: adslist,
      meta: {
        total: totalAds,
        currentPage,
        eachPage,
        lastPage: totalPages,
      },
      status: 200,
    };

    return res.json(response);
  } catch (err) {
    return res.json({ error: err.message });
  }
};

const ad_get_by_id = async (req, res) => {
  try {
    var ads = await Ads.findOne({ _id: req.params.id });
    if (!ads)
      return res.status(404).send("The Ads with the given name is not found.");
  } catch (err) {
    return res.json({ error: err.message });
  }

  return res.json(ads);
};

const ad_update = async (req, res) => {
  try {
    const ads = await Ads.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!ads)
      return res.status(404).send("The Ads with the given name is not found.");
  } catch (err) {
    return res.json({ error: err.message });
  }
  return res.json({
    message: "Ads is updated",
  });
};

const ad_delete = async (req, res) => {
  const ads = await Ads.findByIdAndRemove(req.params.id);
  if (!ads)
    return res.status(404).send("The ads with the given name is not found.");
  return res.json({
    message: "Ads is deleted",
  });
};

const ad_click = async (req, res) => {
  const user = req.user._id;
  try {
    // if ads is already clicked by user for today then return error
    let ad = await AdClick.findOne({
      user: user,
      clickedAt: { $gte: new Date().setHours(0, 0, 0, 0) },
      ad: req.body.ad,
    });
    if (ad) return res.status(400).send("Ad already clicked today.");
    let ads = new AdClick(req.body);
    ads.user = user;
    await ads.save();
  } catch (err) {
    return res.json({ error: err.message });
  }

  return res.json({
    message: "Ad is Clicked",
  });
};

module.exports = {
  create_ad,
  ad_list,
  ads_public,
  ad_get_by_id,
  ad_update,
  ad_delete,
  ad_click,
};
