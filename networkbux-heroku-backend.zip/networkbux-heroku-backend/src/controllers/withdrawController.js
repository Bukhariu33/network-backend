import { Withdraws } from "../models/withdraw";
import User from "../models/user";
const create_withdraw = async (req, res) => {
  const user = req.user._id;
  try {
    let withdraws = new Withdraws(req.body);
    withdraws.user = user;
    await withdraws.save();
  } catch (err) {
    return res.json({ error: err.message });
  }

  return res.json({
    message: "Withdraw Request is Created",
  });
};

const withdraw_list = async (req, res) => {
  const user_id = req.user._id;
  try {
    // const currentPage = parseInt(req.query.page) || 1;
    // const eachPage = 10; // You can adjust this based on your preference.

    // const totalWithdraws = await Withdraws.countDocuments({ user: user_id });
    // const totalPages = Math.ceil(totalWithdraws / eachPage);

    const withdrawlist = await Withdraws.find({ user: user_id });
    // .skip((currentPage - 1) * eachPage)
    // .limit(eachPage);

    const response = {
      data: withdrawlist,
      // meta: {
      //   total: totalWithdraws,
      //   currentPage,
      //   eachPage,
      //   lastPage: totalPages,
      // },
      status: 200,
    };

    return res.json(response);
  } catch (err) {
    return res.json({ error: err.message });
  }
};

const withdraws_public = async (req, res) => {
  try {
    // const currentPage = parseInt(req.query.page) || 1;
    // const eachPage = 10; // You can adjust this based on your preference.

    // const totalWithdraws = await Withdraws.countDocuments();
    // const totalPages = Math.ceil(totalWithdraws / eachPage);

    let withdrawslist = await Withdraws.find();
    // .skip((currentPage - 1) * eachPage)
    // .limit(eachPage);

    if (!withdrawslist)
      return res.status(400).send("Withdraw request not found");

    if (withdrawslist.length > 0) {
      withdrawslist = await Promise.all(
        withdrawslist.map(async (withdraw) => {
          const user = await User.findOne({ _id: withdraw.user });
          withdraw.userData = user;
          return withdraw;
        })
      );
    }

    const response = {
      withdraws: withdrawslist,
      // meta: {
      //   total: totalWithdraws,
      //   currentPage,
      //   eachPage,
      //   lastPage: totalPages,
      // },
      status: 200,
    };

    return res.json(response);
  } catch (err) {
    return res.json({ error: err.message });
  }
};

const withdraw_get_by_id = async (req, res) => {
  try {
    var withdraws = await Withdraws.findOne({ _id: req.params.id });
    if (!withdraws)
      return res
        .status(404)
        .send("The Withdraw Request with the given name is not found.");
  } catch (err) {
    return res.json({ error: err.message });
  }

  return res.json(withdraws);
};

const withdraw_update = async (req, res) => {
  try {
    const withdraws = await Withdraws.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
      }
    );
    if (req.body.status === "approved") {
      await User.findByIdAndUpdate(
        withdraws.user,
        {
          $set: {
            withDrawalAmount: 0,
          },
        },
        { new: false }
      );
    }
    if (!withdraws)
      return res
        .status(404)
        .send("The Withdraw Request with the given name is not found.");
  } catch (err) {
    return res.json({ error: err.message });
  }
  return res.json({
    message: "Withdraw Request is updated",
  });
};

const withdraw_delete = async (req, res) => {
  const withdraws = await Withdraws.findByIdAndRemove(req.params.id);
  if (!withdraws)
    return res
      .status(404)
      .send("The withdraw Request with the given name is not found.");
  return res.json({
    message: "Withdraw Request is deleted",
  });
};
module.exports = {
  create_withdraw,
  withdraw_list,
  withdraws_public,
  withdraw_get_by_id,
  withdraw_update,
  withdraw_delete,
};
