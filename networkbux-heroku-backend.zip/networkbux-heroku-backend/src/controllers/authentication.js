import jwt from "jwt-simple";
import User from "../models/user";
import { dbConfig } from "../config";
import R, { update } from "ramda";
import reset from "../config/resetmail";
import bcrypt from "bcryptjs";

const tokenForUser = (user) => {
  const timestamp = new Date().getTime();

  return jwt.encode({ sub: user.id, iat: timestamp }, dbConfig.secret);
};

export const signup = async (req, res, next) => {
  try {
    const email = req.body.email;

    // see if a user with the given email exists
    User.findOne({ email }, (err, existingUser) => {
      if (err) {
        return next(err);
      }

      // if a user with email does exists, return an error
      if (existingUser) {
        return res.status(422).send({ error: "Email is in use" });
      }
      // generate referralCode for user using email
      const referralCode =
        email.split("@")[0] + Math.floor(1000 + Math.random() * 9000);
      req.body.referralCode = referralCode;
      // if a user with email does not exist, create and save user record
      const user = new User(req.body);
      // user.role = (role) ? role._id : null;
      user.save((err) => {
        if (err) {
          return next(err);
        }

        const r = R.pick(["email"], req.body);
        r["token"] = tokenForUser(user);

        // respond to request indicating the user was created
        res.json({ user: r });
      });
    });
  } catch (err) {
    res.status(500).json({ error: "Internal server error" });
  }
};

export const signin = async (req, res) => {
  try {
    const user = await User.findOne({ email: req.body.email });
    if (!user) {
      return res.json({ error: "Invalid user" });
    }

    // Compare the provided password with the hashed password
    bcrypt.compare(req.body.password, user.password, (err, isMatch) => {
      if (err || !isMatch) {
        return res.json({ error: "Invalid password" });
      }

      // If the password matches, generate and send the token
      const r = R.pick(
        [
          "name",
          "email",
          "role",
          "_id",
          "subscription",
          "referralCode",
          "referralCount",
          "withDrawalAmount",
          "referredBy",
          "totalClicks",
        ],
        user
      );
      r["token"] = tokenForUser(user);
      res.send({ user: r });
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const getuser = async (req, res) => {
  return res.json({ value: req.user });
};

//******************************** Forget password apis ******************************************* */
export const resetmail = async (req, res) => {
  if (!req.body.email) {
    return res.status(422).send({ error: "You must provide an email" });
  }
  let user_email = await User.findOne({ email: req.body.email });
  if (!user_email) {
    return res.status(422).send({ error: "Email does not exist!" });
  }
  let random_number = Math.floor(1000 + Math.random() * 9000);
  reset.mail(req.body.email, "Authentication Code", random_number);
  const user = await User.updateOne(
    { email: req.body.email },
    { $set: { reset_code: random_number } }
  );
  if (user.nModified != 0) {
    res.json({ user: "email sent successfully" });
  }
};

export const reset_code_verify = async (req, res) => {
  let user = await User.findOne({ email: req.body.email });
  if (user.reset_code == req.body.reset_code) {
    //user = await User.updateOne({ email: req.body.email }, { $set: { is_auth: true } });
    res.json({ verify: "reset password code verified successfully" });
  } else {
    res.status(400).json({ verify: "invalid reset password code" });
  }
  // User has already had their email and password auth'd
  // We just need to give them a token
};

export const reset_password = async (req, res) => {
  try {
    if (!req.body.password) {
      return res.status(422).send({ error: "You must provide valid password" });
    }
    let hashed = await bcrypt.hash(req.body.password, 10);
    await User.updateOne(
      { email: req.body.email },
      { $set: { password: hashed } }
    );
  } catch (err) {
    return res.json({ error: err });
  }
  res.json({ message: "Password Updated Successfully" });
};

export const change_password = async (req, res) => {
  try {
    if (!req.body.password) {
      return res.status(422).send({ error: "You must provide valid password" });
    }
    let hashed = await bcrypt.hash(req.body.password, 10);
    const _id = req.params.id;
    await User.updateOne({ _id }, { $set: { password: hashed } });
  } catch (err) {
    return res.status(400).json({ error: err });
  }
  return res.json({ message: "Password Updated Successfully" });
};

export const delete_user = async (req, res) => {
  let user = await User.deleteOne({ email: req.params.id });
  res.json({ message: "User Deleted  Successfully" });
};
