import { AppError, validateError } from "../models/error";

const error = async (req, res) => {
  const { error } = validateError(req.body);
  if (error) return res.status(400).send(error.details[0].message);
  try {
    let error_record = new AppError(req.body);
    await error_record.save();
  } catch (err) {
    return res.json({ error: err.message });
  }
  return res.json({
    message: "Error Record is Created",
  });
};

const error_list = async (req, res) => {
  try {
    var errorlist = await AppError.find({});
    if (!errorlist) return res.status(400).send("Error not found");
  } catch (err) {
    return res.json({ error: err.message });
  }
  return res.json({
    errorlist: errorlist,
  });
};
module.exports = {
  error,
  error_list,
};
