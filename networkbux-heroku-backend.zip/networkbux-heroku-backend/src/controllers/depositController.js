import { Deposits } from "../models/deposit";
import User from "../models/user";
const create_deposit = async (req, res) => {
  const user = req.user._id;
  try {
    let deposits = await Deposits.findOne({
      transactionId: req.body.transactionId,
    });
    if (deposits)
      return res
        .status(400)
        .send("Deposits already Saved for this Transaction Id.");
    deposits = new Deposits(req.body);
    deposits.user = user;
    await deposits.save();
  } catch (err) {
    return res.json({ error: err.message });
  }

  return res.json({
    message: "Deposits is Created",
  });
};

const deposit_list = async (req, res) => {
  const user_id = req.user._id;
  try {
    const currentPage = parseInt(req.query.page) || 1;
    const eachPage = 10; // You can adjust this based on your preference.

    const totalDeposits = await Deposits.countDocuments({ user: user_id });
    const totalPages = Math.ceil(totalDeposits / eachPage);

    const depositlist = await Deposits.find({ user: user_id })
      .skip((currentPage - 1) * eachPage)
      .limit(eachPage);

    const response = {
      data: depositlist,
      meta: {
        total: totalDeposits,
        currentPage,
        eachPage,
        lastPage: totalPages,
      },
      status: 200,
    };

    return res.json(response);
  } catch (err) {
    return res.json({ error: err.message });
  }
};

const deposits_public = async (req, res) => {
  try {
    // const currentPage = parseInt(req.query.page) || 1;
    // const eachPage = 10; // You can adjust this based on your preference.

    // const totalDeposits = await Deposits.countDocuments();
    // const totalPages = Math.ceil(totalDeposits / eachPage);

    let depositslist = await Deposits.find();
    // .skip((currentPage - 1) * eachPage)
    // .limit(eachPage);

    if (!depositslist) return res.status(400).send("Deposits not found");

    if (depositslist.length > 0) {
      depositslist = await Promise.all(
        depositslist.map(async (deposit) => {
          const user = await User.findOne({ _id: deposit.user });
          deposit.userData = user;
          return deposit;
        })
      );
    }

    const response = {
      deposits: depositslist,
      // meta: {
      //   total: totalDeposits,
      //   currentPage,
      //   eachPage,
      //   lastPage: totalPages,
      // },
      status: 200,
    };

    return res.json(response);
  } catch (err) {
    return res.json({ error: err.message });
  }
};

const deposit_get_by_id = async (req, res) => {
  try {
    var deposits = await Deposits.findOne({ _id: req.params.id });
    if (!deposits)
      return res
        .status(404)
        .send("The Deposits with the given name is not found.");
  } catch (err) {
    return res.json({ error: err.message });
  }

  return res.json(deposits);
};

const deposit_update = async (req, res) => {
  try {
    const deposits = await Deposits.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (req.body.status === "approved") {
      await User.findByIdAndUpdate(
        deposits.user,
        {
          $set: {
            "subscription.status": "approved",
          },
        },
        { new: false }
      );
    }
    if (!deposits)
      return res
        .status(404)
        .send("The Deposits with the given name is not found.");
  } catch (err) {
    return res.json({ error: err.message });
  }
  return res.json({
    message: "Deposits is updated",
  });
};

const deposit_delete = async (req, res) => {
  const deposits = await Deposits.findByIdAndRemove(req.params.id);
  if (!deposits)
    return res
      .status(404)
      .send("The deposits with the given name is not found.");
  return res.json({
    message: "Deposits is deleted",
  });
};
module.exports = {
  create_deposit,
  deposit_list,
  deposits_public,
  deposit_get_by_id,
  deposit_update,
  deposit_delete,
};
