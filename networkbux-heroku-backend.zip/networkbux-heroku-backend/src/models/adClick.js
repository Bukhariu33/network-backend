import Joi from "joi";
import mongoose from "mongoose";
const Schema = mongoose.Schema;

// Define our model
const userSchema = new Schema({
  ad: {
    type: Schema.Types.ObjectId,
    ref: "Ads",
    required: true,
  },
  user: {
    type: Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  clickedAt: {
    type: Date
  },
}, { timestamps: true });

const AdClick = mongoose.model("adClick", userSchema);
function validateAds(AdClick) {
  const schema = Joi.object({
    ad: Joi.string().required(),
  });

  return Joi.validate(AdClick, schema);
}

// Export the model
exports.AdClick = AdClick;
exports.validateAds = validateAds;
