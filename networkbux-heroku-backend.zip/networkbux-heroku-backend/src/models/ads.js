import Joi from "joi";
import mongoose from "mongoose";
const Schema = mongoose.Schema;

// Define our model
const userSchema = new Schema({
  link: {
    type: String,
  },
  amount: {
    type: String,
  },
  duration: {
    type: String,
  },
  user: {
    type: Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  status: {
    type: String,
    default: "pending",
  }
});

const Ads = mongoose.model("ads", userSchema);
function validateAds(Ads) {
  const schema = Joi.object({
    link: Joi.string().required(),
  });

  return Joi.validate(Ads, schema);
}

// Export the model
exports.Ads = Ads;
exports.validateAds = validateAds;
