import mongoose from "mongoose";
import bcrypt from "bcrypt";

const Schema = mongoose.Schema;

export const subscriptionSchema = new Schema(
  {
    user: {
      type: Schema.Types.ObjectId,
      ref: "user",
    },
    plan: {
      type: Schema.Types.ObjectId,
      ref: "Plan",
      required: false,
    },
    status: {
      type: String,
      required: false,
      default: "pending",
    },
    created_at: {
      type: Date,
      required: false,
    },
  },
  { timestamps: true }
);

// Define our model
const userSchema = new mongoose.Schema({
  uuid: {
    type: String,
    //default: "uuid"
  },
  name: {
    type: String,
    required: true,
    minlength: 3,
    maxlength: 50,
  },
  email: {
    type: String,
    required: true,
    minlength: 5,
    maxlength: 255,
    unique: true,
  },
  is_auth: {
    type: Boolean,
    default: false,
  },
  auth_code: {
    type: Number,
    //default:0,
    required: false,
  },
  reset_code: {
    type: Number,
    //default:0,
    required: false,
  },
  password: {
    type: String,
    // required: true,
    minlength: 5,
    maxlength: 1024,
  },
  phone: {
    type: String,
    required: false,
    minlength: 5,
    maxlength: 1024,
  },
  address: {
    type: String,
    required: false,
    minlength: 5,
    maxlength: 1024,
  },
  state: {
    type: String,
    required: false,
    minlength: 5,
    maxlength: 1024,
  },
  zip: {
    type: String,
    required: false,
    minlength: 4,
    maxlength: 1024,
  },
  city: {
    type: String,
    required: false,
    minlength: 4,
    maxlength: 1024,
  },
  country: {
    type: String,
    required: false,
    minlength: 4,
    maxlength: 1024,
  },
  role: {
    type: String,
    enum: ["admin", "user", "individualInvestor"],
    default: "user",
  },
  subscription: subscriptionSchema,
  referralCode: {
    type: String,
    default: "",
  },
  referralCount: {
    type: Number,
    default: 0,
  },
  referredBy: {
    type: String,
    default: "",
  },
  withDrawalAmount: {
    type: Number,
    default: 0,
  },
  totalClicks: {
    type: Number,
    default: 0,
  },
  isAdmin: Boolean,
});

// On save hook, encrypt password
// Before saving a model, run this function
userSchema.pre("save", function (next) {
  // get access to the user model
  const user = this;

  // generate a salt then run callback
  bcrypt.genSalt(10, (err, salt) => {
    if (err) {
      return next(err);
    }

    // hash (encrypt) our password using the salt
    bcrypt.hash(user.password, salt, null, (err, hash) => {
      if (err) {
        return next(err);
      }

      // overwrite plain text password with encrypted password
      user.password = hash;
      next();
    });
  });
});

userSchema.methods.comparePassword = function (candidatePassword, callback) {
  bcrypt.compare(candidatePassword, this.password, (err, isMatch) => {
    if (err) {
      return callback(err);
    }

    callback(null, isMatch);
  });
};

// Create the model class
const ModelClass = mongoose.model("user", userSchema);

// Export the model
export default ModelClass;
