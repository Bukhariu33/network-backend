//var nodemailer = require("nodemailer");
import nodemailer from "nodemailer";

var mail = async (email, username, password, link) => {
  try {

    const smtpTransport = nodemailer.createTransport({
      host: "live.smtp.mailtrap.io",
      port: 587,
      secure: false,
      auth: {
        user: "api",
        pass: "980639dede86effb5e38c73c5eef942e",
      },
      tls: {
        rejectUnauthorized: false,
      },
    });

    const mailOptions = {
      from: "support@networkbux.com",
      to: email,
      subject: "NetworkBuxx - Your Authentication Code",
      html: `<h4>Please enter the following 6-digit code to reset your password:</h4><b>Email: ${email} and reset password code: <h1>${password}</h1></b>`,
    };

    const response = await smtpTransport.sendMail(mailOptions);
    console.log("Email sent successfully:", response);
    smtpTransport.close();
  } catch (error) {
    console.error("Error sending email:", error);
  }
};
module.exports.mail = mail;
